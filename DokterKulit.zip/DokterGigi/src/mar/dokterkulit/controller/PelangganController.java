/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mar.dokterkulit.controller;

import mar.doktergigi.model.PelangganModel;
import mar.doktergigi.view.PelangganView;
import javax.swing.JOptionPane;


public class PelangganController {

    private PelangganModel model;

    public void setModel(PelangganModel model) {
        this.model = model;
    }

    public void resetForm(PelangganView view) {

        String nama = (String) view.getTxtNama();
        String email = (String) view.getTxtEmail();
        String noTlp = (String) view.getTxtTelp();

        if (nama.equals("") && email.equals("") && noTlp.equals("")) {

        } else {

            model.resetForm();
        }

    }

    public void simpanForm(PelangganView view) {

        String nama = (String) view.getTxtNama();
        String email = (String) view.getTxtEmail();
        String noTlp = (String) view.getTxtTelp();
        
        if (nama.trim().equals("")) {
            JOptionPane.showMessageDialog(view, "Nama Masih Kosong");
        } else if (email.trim().equals("")) {
            JOptionPane.showMessageDialog(view, "Email Masih Kosong");
        } else if (noTlp.trim().equals("")) {
            JOptionPane.showMessageDialog(view, "No Telp Masih Kosong");
        } else {
            model.simpanForm();
        }
    }

}
