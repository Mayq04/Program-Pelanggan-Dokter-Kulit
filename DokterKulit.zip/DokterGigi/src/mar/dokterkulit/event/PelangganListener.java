
package mar.dokterkulit.event;

import mar.dokterkulit.model.PelangganModel;


public interface PelangganListener {
    
    public void onChange(PelangganModel pelanggan);
    
}
